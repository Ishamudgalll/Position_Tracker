package com.example.positiontracker;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.wearable.activity.WearableActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends WearableActivity implements SensorEventListener{

    private TextView mTextView;
    private SensorManager sensorManager;
    private ImageView status;
    private boolean doSend = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = findViewById(R.id.text);
        status = findViewById(R.id.status);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);


        // Enables Always-on
        setAmbientEnabled();
    }

    @Override
    public void onSensorChanged(final SensorEvent event) {

        Map<String,String> data = new HashMap<>();
        data.put("x", String.valueOf(event.values[0]));
        data.put("y",String.valueOf(event.values[1]));
        data.put("z",String.valueOf(event.values[2]));

        JSONObject jsonData = new JSONObject(data);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, "https://sensor-api-v2.herokuapp.com/home/predict",jsonData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Log.d("Response", String.valueOf(response.get("key")));

                            if (String.valueOf(response.get("key")).equals("0.0")){
                                status.setImageResource(R.drawable.safe);
                            }
                            else{
                                status.setImageResource(R.drawable.danger);
                                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    v.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    //deprecated in API 26
                                    v.vibrate(1000);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        doSend = !doSend;
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_LONG).show();
                error.printStackTrace();
                //doSend = !doSend;
            }
        });

        if (doSend){
            MySingleton.getInstance(this).addToRequestQueue(request);
            doSend = !doSend;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
